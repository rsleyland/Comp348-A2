#ifndef A2_SELECTIONSORT_V2_H
#define A2_SELECTIONSORT_V2_H

void selectionsort(int* arr, int size, int* (*func1)(int*, int));
int* findmin(int* arr, int size);

#endif //A2_SELECTIONSORT_V2_H
