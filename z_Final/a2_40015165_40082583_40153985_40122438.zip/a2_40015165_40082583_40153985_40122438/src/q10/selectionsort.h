#ifndef A2_SELECTIONSORT_H
#define A2_SELECTIONSORT_H

void selectionsort(int* arr, int size);

#endif //A2_SELECTIONSORT_H
